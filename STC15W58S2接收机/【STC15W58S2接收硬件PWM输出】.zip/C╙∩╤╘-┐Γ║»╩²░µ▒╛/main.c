

#include	"config.h"
#include	"PWM.h"
#include 	"PWM_API.h"
#include 	"uart.h"
#include 	"nrf24l01.h"




sbit LED_LINK=P5^1;
sbit LED=P5^2;




uchar rece_buf[32];		//nrf���ջ���
uint chanel1;
uint chanel2;
uint chanel3;
uint chanel4;


/**********************************************/
void main(void)
{
	
	PWM_config();
	while(NRF24L01_Check()); // �ȴ���⵽NRF24L01������Ż�����ִ��
	NRF24L01_RT_Init();	   	 //��ʼ������	
	UartInit();
	
	LED_LINK=0;
	
	P2M0 = 0x00;		//P2ȫ������Ϊ׼˫��ڣ��ڲ���������
	P2M1 = 0x00;
	P3M0 = 0x00;		//P2ȫ������Ϊ׼˫��ڣ��ڲ���������
	P3M1 = 0x00;
	
	
//	EA = 1;

	PWMx_SetPwmWide(PWM2_ID, 0, 256);	//PWM_id: PWMͨ��, PWM2_ID,PWM3_ID,PWM4_ID,PWM5_ID,PWM6_ID,PWM7_ID.
	PWMx_SetPwmWide(PWM3_ID, 0, 512);
	PWMx_SetPwmWide(PWM4_ID, 0, 1024);
	PWMx_SetPwmWide(PWM5_ID, 0, 1280);
	PWMx_SetPwmWide(PWM6_ID, 0, 1536);
	PWMx_SetPwmWide(PWM7_ID, 0, 1792);

	while (1)
	{
		if(NRF_IRQ==0)	 	// �������ģ����յ�����
		{		
			if(NRF24L01_RxPacket(rece_buf)==0)
			{	
				SendData(rece_buf[1]);
				SendData(rece_buf[2]);
				SendData(rece_buf[3]);
				SendData(rece_buf[4]);	
				SendData(rece_buf[5]);
				SendData(rece_buf[6]);
				SendData(rece_buf[7]);
				SendData(rece_buf[8]);	
				
				chanel1 = ( ( ( (uint)rece_buf[1] << 8)  | rece_buf[2] ) >> 1) & 0x07FF;
				chanel2 = ( ( ( (uint)rece_buf[3] << 8)  | rece_buf[4] ) >> 1) & 0x07FF;
				chanel3 = ( ( ( (uint)rece_buf[5] << 8)  | rece_buf[6] ) >> 1) & 0x07FF;
				chanel4 = ( ( ( (uint)rece_buf[7] << 8)  | rece_buf[8] ) >> 1) & 0x07FF;
				if(chanel1 < 2 || chanel1 > 2047)	if(chanel1 > 2047)chanel1 = 2047;else chanel1 = 1;
				if(chanel2 < 2 || chanel2 > 2047)	if(chanel2 > 2047)chanel2 = 2047;else chanel2 = 1;
				if(chanel3 < 2 || chanel3 > 2047)	if(chanel3 > 2047)chanel3 = 2047;else chanel3 = 1;
				if(chanel4 < 2 || chanel4 > 2047)	if(chanel4 > 2047)chanel4 = 2047;else chanel4 = 1;
				
				
//				PWMx_SetPwmWide(PWM2_ID, 0, chanel1);	//���0-100%ռ�ձ�
//				PWMx_SetPwmWide(PWM3_ID, 0, chanel2);
//				PWMx_SetPwmWide(PWM4_ID, 0, chanel3);
//				PWMx_SetPwmWide(PWM5_ID, 0, chanel4);
				
				
				chanel1 = 102 + chanel1/20;				//���5-10%ռ�ձ�
				chanel2 = 102 + chanel2/20;
				chanel3 = 102 + chanel3/20;
				chanel4 = 102 + chanel4/20;
				PWMx_SetPwmWide(PWM2_ID, 0, chanel1);	
				PWMx_SetPwmWide(PWM3_ID, 0, chanel2);
				PWMx_SetPwmWide(PWM4_ID, 0, chanel3);
				PWMx_SetPwmWide(PWM5_ID, 0, chanel4);
			}
		}
	}
}



