#ifndef __UART_H
#define __UART_H

#include	"config.h"

void UartInit();
void SendData(unsigned char ch);
void SendString(char *s);



#endif