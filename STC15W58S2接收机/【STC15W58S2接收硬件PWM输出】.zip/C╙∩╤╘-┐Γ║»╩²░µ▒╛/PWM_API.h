

#ifndef	__PWM_API_H
#define	__PWM_API1_H

#include	"config.h"


void	PWM_config(void);



#endif
